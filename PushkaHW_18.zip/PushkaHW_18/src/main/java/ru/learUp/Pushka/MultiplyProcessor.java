package ru.learUp.Pushka;

public class MultiplyProcessor {

    public Double process(Double arg1, Double arg2) {
        return arg1 * arg2;
    }
}
