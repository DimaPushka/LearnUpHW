package ru.learUp.Pushka;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        ApplicationContext context = new ClassPathXmlApplicationContext("configuration.xml");
        Calculator calculator = context.getBean(Calculator.class);

        Scanner num = new Scanner(System.in);
        float first, second;
        System.out.print("Введите первое число: ");
        first = num.nextFloat();
        System.out.print("Введите второе число: ");
        second = num.nextFloat();
        System.out.print("Выберете математическое действие: '+', '-', '*', '/':  ");

        String operator = num.next();
        while (!operator.equals("+") && !operator.equals("-") && !operator.equals("*") && !operator.equals("/")) {
            System.out.print("Не правильное математическое действие! Введите правильное значение.");
            operator = num.next();
        }

        switch (operator) {
            case "+" -> System.out.println(calculator.sum((double) first, (double) second));
            case "-" -> System.out.println(calculator.subtract((double) first, (double) second));
            case "/" -> System.out.println(calculator.divide((double) first, (double) second));
            case "*" -> System.out.println(calculator.multiply((double) first, (double) second));
        }


    }
}
