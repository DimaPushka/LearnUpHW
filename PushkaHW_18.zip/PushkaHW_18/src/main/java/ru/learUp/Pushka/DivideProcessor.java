package ru.learUp.Pushka;

public class DivideProcessor {

    public Double process(Double arg1, Double arg2) {
        return arg1 / arg2;
    }
}
